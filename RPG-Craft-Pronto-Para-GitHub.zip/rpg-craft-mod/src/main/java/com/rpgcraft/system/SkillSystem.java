package com.rpgcraft.system;

import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.data.PlayerData;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Habilidades ativas por classe: 3 skills + 1 ultimate.
 * Cada uma gasta mana e tem tempo de recarga (cooldown).
 */
public class SkillSystem {

    // índice 1..4 (0 não usado)
    private static final int[] MANA_COST = {0, 10, 15, 20, 50};
    private static final int[] BASE_COOLDOWN_SECONDS = {0, 8, 12, 18, 60};

    private static final Map<UUID, long[]> COOLDOWNS = new HashMap<>();

    public static void clearPlayer(UUID id) {
        COOLDOWNS.remove(id);
    }

    // ==================== Nomes das habilidades ====================

    public static String[] names(PlayerClass pc) {
        return switch (pc) {
            case ESPADACHIM -> new String[]{"Golpe Giratório", "Postura de Ferro", "Investida", "Fúria de Batalha"};
            case ARTESAO    -> new String[]{"Mãos de Mestre", "Forja Interior", "Olho de Artesão", "Inspiração Lendária"};
            case ARQUEIRO   -> new String[]{"Passo Leve", "Salto do Falcão", "Olho de Águia", "Caçador Supremo"};
            case MAGO       -> new String[]{"Nova de Fogo", "Barreira Arcana", "Pulso Gélido", "Meteoro Arcano"};
            case MINEIRO    -> new String[]{"Pressa das Profundezas", "Pele de Pedra", "Visão das Profundezas", "Terremoto"};
            case ASSASSINO  -> new String[]{"Sombras", "Passo Sombrio", "Golpe Mortal", "Dança das Lâminas"};
            case PALADINO   -> new String[]{"Bênção", "Mão Curativa", "Luz Sagrada", "Aura Divina"};
            default         -> new String[]{"-", "-", "-", "-"};
        };
    }

    // ==================== Melhorar skill ====================

    public static boolean unlockSkill(ServerPlayerEntity player, int skillSlot) {
        PlayerData data = ClassManager.getData(player);
        if (!data.hasChosenClass() || data.getSkillPoints() <= 0) return false;

        int current;
        switch (skillSlot) {
            case 1 -> current = data.getSkill1();
            case 2 -> current = data.getSkill2();
            case 3 -> current = data.getSkill3();
            case 4 -> current = data.getUltimate();
            default -> { return false; }
        }

        // Máximo nível 5 para skills normais, 3 para ultimate
        int max = (skillSlot == 4) ? 3 : 5;
        if (current >= max) return false;

        data.setSkillPoints(data.getSkillPoints() - 1);

        switch (skillSlot) {
            case 1 -> data.setSkill1(current + 1);
            case 2 -> data.setSkill2(current + 1);
            case 3 -> data.setSkill3(current + 1);
            case 4 -> data.setUltimate(current + 1);
        }

        String name = names(data.getPlayerClass())[skillSlot - 1];
        player.sendMessage(Text.literal("§a✦ " + name + " melhorou para o Nv." + (current + 1) + "!"), false);
        return true;
    }

    // ==================== Cooldown ====================

    private static double cooldownReduction(PlayerData data) {
        return Math.min(0.5, data.getIntelligence() * 0.005);
    }

    /** Segundos restantes de recarga (0 = pronta). */
    public static int cooldownLeft(ServerPlayerEntity player, int slot) {
        long[] cd = COOLDOWNS.get(player.getUuid());
        if (cd == null) return 0;
        long left = cd[slot] - player.server.getTicks();
        return left <= 0 ? 0 : (int) Math.ceil(left / 20.0);
    }

    /** Texto compacto para a barra de ação: [1✓] [2 5s] ... */
    public static String hudCooldowns(ServerPlayerEntity player, PlayerData data) {
        StringBuilder sb = new StringBuilder();
        int[] levels = {0, data.getSkill1(), data.getSkill2(), data.getSkill3(), data.getUltimate()};
        String[] keys = {"", "Z", "X", "C", "V"};
        for (int slot = 1; slot <= 4; slot++) {
            if (levels[slot] <= 0) continue;
            int left = cooldownLeft(player, slot);
            if (left == 0) {
                sb.append("§a[").append(keys[slot]).append("] ");
            } else {
                sb.append("§c[").append(keys[slot]).append(" ").append(left).append("s] ");
            }
        }
        return sb.toString();
    }

    // ==================== Ativar skill ====================

    public static void activateSkill(ServerPlayerEntity player, int slot) {
        PlayerData data = ClassManager.getData(player);
        if (!data.hasChosenClass()) return;
        if (slot < 1 || slot > 4) return;

        int level;
        switch (slot) {
            case 1 -> level = data.getSkill1();
            case 2 -> level = data.getSkill2();
            case 3 -> level = data.getSkill3();
            default -> level = data.getUltimate();
        }

        if (level <= 0) {
            player.sendMessage(Text.literal("§cEssa habilidade ainda não foi desbloqueada! (/rpg skill unlock " + slot + ")"), true);
            return;
        }

        int left = cooldownLeft(player, slot);
        if (left > 0) {
            player.sendMessage(Text.literal("§cEm recarga: " + left + "s"), true);
            return;
        }

        int cost = MANA_COST[slot];
        if (!ManaSystem.spend(player, cost)) {
            player.sendMessage(Text.literal("§9Mana insuficiente! §7(precisa de " + cost + ")"), true);
            return;
        }

        long[] cd = COOLDOWNS.computeIfAbsent(player.getUuid(), k -> new long[5]);
        double seconds = BASE_COOLDOWN_SECONDS[slot] * (1.0 - cooldownReduction(data));
        cd[slot] = player.server.getTicks() + (long) (seconds * 20);

        PlayerClass pc = data.getPlayerClass();
        perform(player, data, pc, slot, level);

        String name = names(pc)[slot - 1];
        player.sendMessage(Text.literal("§b✦ " + name + " §7(Nv." + level + ")"), true);
    }

    // ==================== Efeitos de cada habilidade ====================

    private static void perform(ServerPlayerEntity p, PlayerData d, PlayerClass pc, int slot, int level) {
        int duration = 100 + level * 40;          // ticks
        int amp = Math.min(2, level - 1);         // amplificador de efeito
        int str = d.getStrength();
        int dex = d.getDexterity();
        int intel = d.getIntelligence();

        switch (pc) {

            case ESPADACHIM -> {
                switch (slot) {
                    case 1 -> {
                        hitAll(p, 3.5, 4 + level * 1.5f + str * 0.25f, 0.7, 0);
                        fx(p, ParticleTypes.SWEEP_ATTACK, 14, 1.4, 0.0);
                        sound(p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.9f);
                    }
                    case 2 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, duration, amp));
                        fx(p, ParticleTypes.CRIT, 20, 0.6, 0.1);
                        sound(p, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 0.8f);
                    }
                    case 3 -> {
                        dash(p, 1.4 + level * 0.1);
                        hitAll(p, 2.5, 3 + level * 1.0f + str * 0.2f, 0.5, 0);
                        fx(p, ParticleTypes.CRIT, 20, 0.5, 0.2);
                        sound(p, SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.0f);
                    }
                    default -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 300 + level * 60, 1));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300 + level * 60, 1));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 0));
                        fx(p, ParticleTypes.ANGRY_VILLAGER, 15, 0.7, 0.0);
                        sound(p, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.0f);
                    }
                }
            }

            case ARTESAO -> {
                switch (slot) {
                    case 1 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, duration, amp + 1));
                        fx(p, ParticleTypes.ENCHANT, 25, 0.6, 0.3);
                        sound(p, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f);
                    }
                    case 2 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, duration, amp));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, 40, 1));
                        fx(p, ParticleTypes.HEART, 8, 0.5, 0.0);
                        sound(p, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f);
                    }
                    case 3 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, duration * 3, 0));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, duration * 3, amp));
                        fx(p, ParticleTypes.END_ROD, 15, 0.5, 0.05);
                        sound(p, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.4f);
                    }
                    default -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 400, 2));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 400, 0));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 400, 1));
                        fx(p, ParticleTypes.ENCHANT, 60, 1.0, 0.4);
                        sound(p, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.0f);
                    }
                }
            }

            case ARQUEIRO -> {
                switch (slot) {
                    case 1 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, duration, amp));
                        fx(p, ParticleTypes.CLOUD, 10, 0.4, 0.05);
                        sound(p, SoundEvents.ENTITY_BAT_TAKEOFF, 1.2f);
                    }
                    case 2 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, duration, amp + 1));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, duration, 0));
                        fx(p, ParticleTypes.CLOUD, 15, 0.4, 0.1);
                        sound(p, SoundEvents.ENTITY_BAT_TAKEOFF, 0.8f);
                    }
                    case 3 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, duration * 2, 0));
                        glowAll(p, 20, duration);
                        fx(p, ParticleTypes.END_ROD, 20, 0.6, 0.05);
                        sound(p, SoundEvents.ENTITY_EVOKER_CAST_SPELL, 1.4f);
                    }
                    default -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 2));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 300, 0));
                        glowAll(p, 30, 300);
                        fx(p, ParticleTypes.END_ROD, 40, 1.0, 0.1);
                        sound(p, SoundEvents.ENTITY_EVOKER_CAST_SPELL, 0.8f);
                    }
                }
            }

            case MAGO -> {
                switch (slot) {
                    case 1 -> {
                        hitAll(p, 5.0, 4 + level * 1.5f + intel * 0.3f, 0.4, 3 + level);
                        fx(p, ParticleTypes.FLAME, 50, 2.0, 0.05);
                        sound(p, SoundEvents.ENTITY_BLAZE_SHOOT, 1.0f);
                    }
                    case 2 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, duration, Math.min(3, level)));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, duration, 0));
                        fx(p, ParticleTypes.ENCHANT, 40, 0.8, 0.4);
                        sound(p, SoundEvents.ENTITY_EVOKER_CAST_SPELL, 1.0f);
                    }
                    case 3 -> {
                        slowAll(p, 6.0, 3 + level * 1.0f + intel * 0.2f, 100 + level * 20);
                        fx(p, ParticleTypes.SNOWFLAKE, 60, 2.5, 0.05);
                        sound(p, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0.6f);
                    }
                    default -> {
                        hitAll(p, 9.0, 12 + level * 4.0f + intel * 0.5f, 1.0, 6);
                        fx(p, ParticleTypes.EXPLOSION_EMITTER, 1, 0.0, 0.0);
                        fx(p, ParticleTypes.FLAME, 120, 4.0, 0.1);
                        sound(p, SoundEvents.ENTITY_GENERIC_EXPLODE, 1.0f);
                    }
                }
            }

            case MINEIRO -> {
                switch (slot) {
                    case 1 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, duration, amp + 1));
                        fx(p, ParticleTypes.CRIT, 15, 0.5, 0.1);
                        sound(p, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 1.2f);
                    }
                    case 2 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, duration, amp));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, duration, 0));
                        fx(p, ParticleTypes.LARGE_SMOKE, 15, 0.5, 0.02);
                        sound(p, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 0.7f);
                    }
                    case 3 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, duration * 3, 0));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, duration * 3, amp));
                        fx(p, ParticleTypes.END_ROD, 15, 0.5, 0.05);
                        sound(p, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f);
                    }
                    default -> {
                        hitAll(p, 7.0, 8 + level * 3.0f + str * 0.3f, 0.8, 0);
                        slowAll(p, 7.0, 0, 100);
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 200, 2));
                        fx(p, ParticleTypes.LARGE_SMOKE, 80, 3.5, 0.05);
                        sound(p, SoundEvents.ENTITY_GENERIC_EXPLODE, 0.6f);
                    }
                }
            }

            case ASSASSINO -> {
                switch (slot) {
                    case 1 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, duration / 2 + 40, 0));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, duration / 2 + 40, 0));
                        fx(p, ParticleTypes.SMOKE, 30, 0.5, 0.02);
                        sound(p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.2f);
                    }
                    case 2 -> {
                        dash(p, 1.8 + level * 0.1);
                        fx(p, ParticleTypes.PORTAL, 40, 0.6, 0.3);
                        sound(p, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.0f);
                    }
                    case 3 -> {
                        LivingEntity target = nearestEnemy(p, 5.0);
                        if (target != null) {
                            hurt(p, target, 8 + level * 2.5f + str * 0.3f + dex * 0.2f);
                            target.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1));
                            ((ServerWorld) p.getWorld()).spawnParticles(ParticleTypes.CRIT,
                                    target.getX(), target.getBodyY(0.5), target.getZ(), 30, 0.4, 0.5, 0.4, 0.3);
                            sound(p, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.0f);
                        } else {
                            p.sendMessage(Text.literal("§7Nenhum inimigo por perto."), true);
                        }
                    }
                    default -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 160, 0));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 160, 2));
                        hitAll(p, 4.0, 7 + level * 3.0f + dex * 0.3f, 0.3, 0);
                        fx(p, ParticleTypes.SWEEP_ATTACK, 25, 2.0, 0.0);
                        sound(p, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.3f);
                    }
                }
            }

            case PALADINO -> {
                switch (slot) {
                    case 1 -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, duration, amp));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, duration, 0));
                        fx(p, ParticleTypes.END_ROD, 25, 0.6, 0.05);
                        sound(p, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.3f);
                    }
                    case 2 -> {
                        p.heal(6 + level * 2.0f + intel * 0.2f);
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100, 0));
                        fx(p, ParticleTypes.HEART, 12, 0.6, 0.0);
                        sound(p, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.2f);
                    }
                    case 3 -> {
                        hitAll(p, 6.0, 4 + level * 1.5f + intel * 0.2f, 0.4, 0);
                        fx(p, ParticleTypes.END_ROD, 50, 2.5, 0.1);
                        sound(p, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.6f);
                    }
                    default -> {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 250, 1));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 250, 1));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 250, 2));
                        p.heal(10);
                        hitAll(p, 6.0, 6 + level * 2.0f, 0.5, 0);
                        fx(p, ParticleTypes.TOTEM_OF_UNDYING, 60, 1.0, 0.3);
                        sound(p, SoundEvents.ITEM_TOTEM_USE, 1.0f);
                    }
                }
            }

            default -> { }
        }
    }

    // ==================== Utilidades ====================

    private static ServerWorld world(ServerPlayerEntity p) {
        return (ServerWorld) p.getWorld();
    }

    private static void fx(ServerPlayerEntity p, ParticleEffect type, int count, double spread, double speed) {
        world(p).spawnParticles(type, p.getX(), p.getBodyY(0.5), p.getZ(), count, spread, 0.5, spread, speed);
    }

    private static void sound(ServerPlayerEntity p, SoundEvent event, float pitch) {
        world(p).playSound(null, p.getBlockPos(), event, SoundCategory.PLAYERS, 1.0f, pitch);
    }

    private static List<LivingEntity> enemies(ServerPlayerEntity p, double radius) {
        Box box = p.getBoundingBox().expand(radius);
        List<LivingEntity> found = world(p).getEntitiesByClass(LivingEntity.class, box,
                e -> e != p && e.isAlive() && e instanceof Monster);
        List<LivingEntity> result = new ArrayList<>();
        for (LivingEntity e : found) {
            if (e.squaredDistanceTo(p) <= radius * radius) result.add(e);
        }
        return result;
    }

    private static LivingEntity nearestEnemy(ServerPlayerEntity p, double radius) {
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (LivingEntity e : enemies(p, radius)) {
            double dist = e.squaredDistanceTo(p);
            if (dist < bestDist) {
                bestDist = dist;
                best = e;
            }
        }
        return best;
    }

    private static void hurt(ServerPlayerEntity p, LivingEntity target, float amount) {
        target.damage(world(p).getDamageSources().playerAttack(p), amount);
    }

    /** Dano em área. knockback = força do empurrão, fireSeconds = tempo em chamas. */
    private static void hitAll(ServerPlayerEntity p, double radius, float amount, double knockback, int fireSeconds) {
        for (LivingEntity e : enemies(p, radius)) {
            hurt(p, e, amount);
            if (fireSeconds > 0) e.setOnFireFor(fireSeconds);
            if (knockback > 0) e.takeKnockback(knockback, p.getX() - e.getX(), p.getZ() - e.getZ());
        }
    }

    private static void slowAll(ServerPlayerEntity p, double radius, float amount, int ticks) {
        for (LivingEntity e : enemies(p, radius)) {
            if (amount > 0) hurt(p, e, amount);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks, 2));
        }
    }

    private static void glowAll(ServerPlayerEntity p, double radius, int ticks) {
        for (LivingEntity e : enemies(p, radius)) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, ticks, 0));
        }
    }

    private static void dash(ServerPlayerEntity p, double power) {
        Vec3d look = p.getRotationVec(1.0f);
        p.setVelocity(look.x * power, Math.max(0.15, look.y * 0.3), look.z * power);
        p.velocityModified = true;
    }

    // ==================== Tela de habilidades ====================

    public static void showSkills(ServerPlayerEntity player) {
        PlayerData data = ClassManager.getData(player);
        String[] n = names(data.getPlayerClass());
        int[] lv = {data.getSkill1(), data.getSkill2(), data.getSkill3(), data.getUltimate()};
        String[] keys = {"Z", "X", "C", "V"};

        player.sendMessage(Text.literal("§6§l════ HABILIDADES ════"), false);
        player.sendMessage(Text.literal("§eSkill Points: §f" + data.getSkillPoints()
                + "   §9Mana: §f" + (int) ManaSystem.get(player) + "/" + ManaSystem.getMax(player)), false);
        for (int i = 0; i < 4; i++) {
            int slot = i + 1;
            player.sendMessage(Text.literal("§7[" + slot + "] §f" + n[i] + " §7Nv." + lv[i]
                    + " §8| §9" + MANA_COST[slot] + " mana §8| §7recarga " + BASE_COOLDOWN_SECONDS[slot] + "s §8| tecla §f" + keys[i]), false);
        }
        player.sendMessage(Text.literal("§7Melhorar: §f/rpg skill unlock <1-4>  §7Usar: §f/rpg skill use <1-4>"), false);
    }
}
