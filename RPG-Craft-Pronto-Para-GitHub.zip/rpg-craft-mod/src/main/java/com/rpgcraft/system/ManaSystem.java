package com.rpgcraft.system;

import com.rpgcraft.classsystem.ClassManager;
import com.rpgcraft.classsystem.PlayerClass;
import com.rpgcraft.data.PlayerData;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Sistema de Mana. A mana não é salva no mundo: ela enche ao entrar e regenera sozinha.
 * Mana máxima = 30 + Inteligência x4 + Nível x2 (Mago ganha +30).
 */
public class ManaSystem {

    private static final Map<UUID, Float> MANA = new HashMap<>();

    public static int getMax(ServerPlayerEntity player) {
        PlayerData d = ClassManager.getData(player);
        int max = 30 + d.getIntelligence() * 4 + d.getLevel() * 2;
        if (d.getPlayerClass() == PlayerClass.MAGO) max += 30;
        return max;
    }

    public static float get(ServerPlayerEntity player) {
        int max = getMax(player);
        Float value = MANA.get(player.getUuid());
        if (value == null) {
            value = (float) max;
            MANA.put(player.getUuid(), value);
        }
        return Math.min(value, (float) max);
    }

    public static boolean spend(ServerPlayerEntity player, int cost) {
        float current = get(player);
        if (current < cost) return false;
        MANA.put(player.getUuid(), current - cost);
        return true;
    }

    public static void refill(ServerPlayerEntity player) {
        MANA.put(player.getUuid(), (float) getMax(player));
    }

    /** Chamado todo tick de servidor para jogadores com classe. */
    public static void tick(ServerPlayerEntity player) {
        PlayerData d = ClassManager.getData(player);
        float perSecond = 1.5f + d.getIntelligence() * 0.05f;
        if (d.getPlayerClass() == PlayerClass.MAGO) perSecond *= 1.5f;
        float next = get(player) + perSecond / 20.0f;
        MANA.put(player.getUuid(), Math.min(next, (float) getMax(player)));
    }

    public static void remove(UUID id) {
        MANA.remove(id);
    }
}
