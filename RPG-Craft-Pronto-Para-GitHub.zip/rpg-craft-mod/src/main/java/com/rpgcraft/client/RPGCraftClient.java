package com.rpgcraft.client;

import com.rpgcraft.network.ModPackets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class RPGCraftClient implements ClientModInitializer {

    private static final KeyBinding[] SKILL_KEYS = new KeyBinding[4];

    @Override
    public void onInitializeClient() {
        // O servidor manda abrir a tela de classe quando o jogador ainda não escolheu
        ClientPlayNetworking.registerGlobalReceiver(ModPackets.OPEN_CLASS_SCREEN,
                (client, handler, buf, responseSender) ->
                        client.execute(() -> client.setScreen(new ClassSelectionScreen())));

        // Teclas das habilidades: Z, X, C e V (podem ser mudadas em Controles)
        int[] keys = {GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V};
        String[] ids = {"skill1", "skill2", "skill3", "ultimate"};
        for (int i = 0; i < 4; i++) {
            SKILL_KEYS[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.rpgcraft." + ids[i], InputUtil.Type.KEYSYM, keys[i], "category.rpgcraft"));
        }

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            for (int i = 0; i < 4; i++) {
                while (SKILL_KEYS[i].wasPressed()) {
                    ClientPlayNetworking.send(ModPackets.USE_SKILL, ModPackets.createUseSkillPacket(i + 1));
                }
            }
        });
    }
}
