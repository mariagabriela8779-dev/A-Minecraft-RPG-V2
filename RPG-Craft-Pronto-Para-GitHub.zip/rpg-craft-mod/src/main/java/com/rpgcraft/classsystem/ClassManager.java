package com.rpgcraft.classsystem;

import com.rpgcraft.data.PlayerData;
import com.rpgcraft.data.PlayerDataHolder;
import com.rpgcraft.system.AttributeEffects;
import com.rpgcraft.system.ManaSystem;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ClassManager {

    public static void init() {}

    public static PlayerData getData(PlayerEntity player) {
        if (player instanceof PlayerDataHolder holder) {
            return holder.rpgcraft$getData();
        }
        return PlayerData.createDefault();
    }

    public static void setClass(ServerPlayerEntity player, PlayerClass newClass) {
        PlayerData data = getData(player);
        data.setPlayerClass(newClass);
        data.setLevel(1);
        data.setExperience(0);
        data.setSkillPoints(3);
        data.setAttributePoints(5);
        data.setHasChosenClass(true);

        applyStartingAttributes(data, newClass);

        player.sendMessage(Text.literal("§6§l✦ Classe escolhida: ")
                .append(newClass.getStyledName())
                .append(Text.literal(" §7- Que sua jornada comece!")), false);

        player.sendMessage(Text.literal("§e+5 Attribute Points  +3 Skill Points"), false);
        player.sendMessage(Text.literal("§7/rpg attr <atributo>  |  /rpg skill"), false);

        applyClassBonuses(player, newClass);
        AttributeEffects.apply(player);
    }

    private static void applyStartingAttributes(PlayerData data, PlayerClass pc) {
        switch (pc) {
            case ESPADACHIM -> data.setStrength(3);
            case ARTESAO -> data.setIntelligence(2);
            case ARQUEIRO -> data.setDexterity(3);
            case MAGO -> data.setIntelligence(4);
            case MINEIRO -> data.setVitality(2);
            case ASSASSINO -> { data.setDexterity(2); data.setStrength(1); }
            case PALADINO -> { data.setVitality(2); data.setStrength(2); }
            default -> {}
        }
    }

    private static void applyClassBonuses(ServerPlayerEntity player, PlayerClass pc) {
        switch (pc) {
            case ESPADACHIM -> player.sendMessage(Text.literal("§c+ Força e resistência de combate!"), false);
            case ARTESAO -> player.sendMessage(Text.literal("§6+ Maestria de criação!"), false);
            case ARQUEIRO -> player.sendMessage(Text.literal("§a+ Precisão e agilidade!"), false);
            case MAGO -> player.sendMessage(Text.literal("§d+ Poder elemental!"), false);
            case MINEIRO -> player.sendMessage(Text.literal("§b+ Sorte das profundezas!"), false);
            case ASSASSINO -> player.sendMessage(Text.literal("§8+ Sombra e veneno!"), false);
            case PALADINO -> player.sendMessage(Text.literal("§e+ Proteção sagrada e cura!"), false);
            default -> {}
        }
    }

    public static void addXp(ServerPlayerEntity player, int amount) {
        PlayerData data = getData(player);
        if (!data.hasChosenClass()) return;

        int oldLevel = data.getLevel();
        data.addExperience(amount);

        if (data.getLevel() > oldLevel) {
            player.sendMessage(Text.literal("§a§l⬆ LEVEL UP! §6Nível " + data.getLevel() + " §7(+2 Skill +1 Attr)"), false);
            if (data.getLevel() % 5 == 0) {
                player.sendMessage(Text.literal("§6§l✦ Bônus de nível especial! +1 Attr extra"), false);
            }

            AttributeEffects.apply(player);
            player.setHealth(player.getMaxHealth());
            ManaSystem.refill(player);

            ServerWorld world = (ServerWorld) player.getWorld();
            world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0f, 1.0f);
            world.spawnParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getBodyY(0.5), player.getZ(),
                    40, 0.5, 0.8, 0.5, 0.2);

            player.networkHandler.sendPacket(new TitleS2CPacket(
                    Text.literal("⬆ NÍVEL " + data.getLevel()).formatted(Formatting.GOLD, Formatting.BOLD)));
            player.networkHandler.sendPacket(new SubtitleS2CPacket(
                    Text.literal("Você ficou mais forte!").formatted(Formatting.YELLOW)));
        } else {
            player.sendMessage(Text.literal("§a+" + amount + " XP"), true);
        }
    }

    public static void onAttributesChanged(ServerPlayerEntity player) {
        AttributeEffects.apply(player);
    }
}
