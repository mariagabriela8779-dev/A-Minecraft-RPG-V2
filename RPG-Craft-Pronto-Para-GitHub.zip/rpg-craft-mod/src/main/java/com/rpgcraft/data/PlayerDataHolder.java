package com.rpgcraft.data;


public interface PlayerDataHolder {
    PlayerData rpgcraft$getData();
    void rpgcraft$setData(PlayerData data);
}
