package com.rpgcraft.data;

import com.rpgcraft.classsystem.PlayerClass;
import net.minecraft.nbt.NbtCompound;

/**
 * Dados persistentes do jogador no RPG Craft.
 * Compatível com saves antigos (campos novos recebem valor padrão).
 */
public class PlayerData {
    public static final String NBT_KEY = "RPGCraftData";

    // ===== Classe e Progressão =====
    private PlayerClass playerClass = PlayerClass.NONE;
    private int level = 1;
    private int experience = 0;
    private boolean hasChosenClass = false;

    // ===== Pontos =====
    private int skillPoints = 0;      // pontos de habilidade
    private int attributePoints = 0;  // pontos de atributo

    // ===== Atributos =====
    private int strength = 0;     // Força      → dano físico
    private int vitality = 0;     // Vitalidade  → vida máxima + regeneração
    private int dexterity = 0;    // Destreza    → velocidade + chance crítico
    private int intelligence = 0; // Inteligência → poder mágico + redução cooldown

    // ===== Skills (0 = bloqueada, 1+ = nível da skill) =====
    private int skill1 = 0;
    private int skill2 = 0;
    private int skill3 = 0;
    private int ultimate = 0;

    // ==================== Getters / Setters ====================

    public PlayerClass getPlayerClass() {
        return playerClass;
    }

    public void setPlayerClass(PlayerClass playerClass) {
        this.playerClass = playerClass;
        this.hasChosenClass = true;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = Math.max(1, Math.min(100, level));
    }

    public int getExperience() {
        return experience;
    }

    public void addExperience(int amount) {
        if (amount <= 0) return;
        this.experience += amount;
        checkLevelUp();
    }

    public void setExperience(int experience) {
        this.experience = Math.max(0, experience);
    }

    public boolean hasChosenClass() {
        return hasChosenClass;
    }

    public void setHasChosenClass(boolean hasChosenClass) {
        this.hasChosenClass = hasChosenClass;
    }

    // Pontos
    public int getSkillPoints() {
        return skillPoints;
    }

    public void setSkillPoints(int skillPoints) {
        this.skillPoints = Math.max(0, skillPoints);
    }

    public void addSkillPoints(int amount) {
        this.skillPoints = Math.max(0, this.skillPoints + amount);
    }

    public int getAttributePoints() {
        return attributePoints;
    }

    public void setAttributePoints(int attributePoints) {
        this.attributePoints = Math.max(0, attributePoints);
    }

    public void addAttributePoints(int amount) {
        this.attributePoints = Math.max(0, this.attributePoints + amount);
    }

    // Atributos
    public int getStrength() { return strength; }
    public void setStrength(int v) { this.strength = Math.max(0, Math.min(100, v)); }

    public int getVitality() { return vitality; }
    public void setVitality(int v) { this.vitality = Math.max(0, Math.min(100, v)); }

    public int getDexterity() { return dexterity; }
    public void setDexterity(int v) { this.dexterity = Math.max(0, Math.min(100, v)); }

    public int getIntelligence() { return intelligence; }
    public void setIntelligence(int v) { this.intelligence = Math.max(0, Math.min(100, v)); }

    /**
     * Tenta gastar 1 ponto de atributo no atributo escolhido.
     * @return true se conseguiu gastar o ponto
     */
    public boolean spendAttributePoint(String attribute) {
        if (attributePoints <= 0) return false;

        switch (attribute.toLowerCase()) {
            case "strength", "forca", "força", "str" -> {
                if (strength >= 100) return false;
                strength++;
                attributePoints--;
                return true;
            }
            case "vitality", "vitalidade", "vit" -> {
                if (vitality >= 100) return false;
                vitality++;
                attributePoints--;
                return true;
            }
            case "dexterity", "destreza", "dex" -> {
                if (dexterity >= 100) return false;
                dexterity++;
                attributePoints--;
                return true;
            }
            case "intelligence", "inteligencia", "inteligência", "int" -> {
                if (intelligence >= 100) return false;
                intelligence++;
                attributePoints--;
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    // Skills
    public int getSkill1() { return skill1; }
    public void setSkill1(int v) { this.skill1 = Math.max(0, v); }
    public int getSkill2() { return skill2; }
    public void setSkill2(int v) { this.skill2 = Math.max(0, v); }
    public int getSkill3() { return skill3; }
    public void setSkill3(int v) { this.skill3 = Math.max(0, v); }
    public int getUltimate() { return ultimate; }
    public void setUltimate(int v) { this.ultimate = Math.max(0, v); }

    // ==================== Lógica de Nível ====================

    private void checkLevelUp() {
        int required = getXpForNextLevel();
        while (experience >= required && level < 100) {
            experience -= required;
            level++;

            // Recompensas por nível
            skillPoints += 2;          // 2 pontos de habilidade
            attributePoints += 1;      // 1 ponto de atributo

            // A cada 5 níveis ganha ponto extra de atributo
            if (level % 5 == 0) {
                attributePoints += 1;
            }

            required = getXpForNextLevel();
        }
    }

    public int getXpForNextLevel() {
        // Curva suave: 100 + 50*lvl + 5*lvl²
        return 100 + (level * 50) + (level * level * 5);
    }

    public float getXpProgress() {
        int needed = getXpForNextLevel();
        if (needed <= 0) return 1.0f;
        return Math.min(1.0f, (float) experience / (float) needed);
    }

    // ==================== NBT ====================

    public NbtCompound writeNbt() {
        NbtCompound nbt = new NbtCompound();

        nbt.putString("Class", playerClass.getId());
        nbt.putInt("Level", level);
        nbt.putInt("Experience", experience);
        nbt.putBoolean("HasChosenClass", hasChosenClass);

        nbt.putInt("SkillPoints", skillPoints);
        nbt.putInt("AttributePoints", attributePoints);

        nbt.putInt("Strength", strength);
        nbt.putInt("Vitality", vitality);
        nbt.putInt("Dexterity", dexterity);
        nbt.putInt("Intelligence", intelligence);

        nbt.putInt("Skill1", skill1);
        nbt.putInt("Skill2", skill2);
        nbt.putInt("Skill3", skill3);
        nbt.putInt("Ultimate", ultimate);

        return nbt;
    }

    public void readNbt(NbtCompound nbt) {
        if (nbt.contains("Class")) {
            this.playerClass = PlayerClass.fromId(nbt.getString("Class"));
        }
        this.level = nbt.contains("Level") ? nbt.getInt("Level") : 1;
        this.experience = nbt.contains("Experience") ? nbt.getInt("Experience") : 0;
        this.hasChosenClass = nbt.contains("HasChosenClass") && nbt.getBoolean("HasChosenClass");

        this.skillPoints = nbt.contains("SkillPoints") ? nbt.getInt("SkillPoints") : 0;
        this.attributePoints = nbt.contains("AttributePoints") ? nbt.getInt("AttributePoints") : 0;

        this.strength = nbt.contains("Strength") ? nbt.getInt("Strength") : 0;
        this.vitality = nbt.contains("Vitality") ? nbt.getInt("Vitality") : 0;
        this.dexterity = nbt.contains("Dexterity") ? nbt.getInt("Dexterity") : 0;
        this.intelligence = nbt.contains("Intelligence") ? nbt.getInt("Intelligence") : 0;

        this.skill1 = nbt.contains("Skill1") ? nbt.getInt("Skill1") : 0;
        this.skill2 = nbt.contains("Skill2") ? nbt.getInt("Skill2") : 0;
        this.skill3 = nbt.contains("Skill3") ? nbt.getInt("Skill3") : 0;
        this.ultimate = nbt.contains("Ultimate") ? nbt.getInt("Ultimate") : 0;
    }

    public static PlayerData createDefault() {
        return new PlayerData();
    }
}
